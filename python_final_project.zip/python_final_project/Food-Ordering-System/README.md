# Food-Ordering-System

Online Food Ordering System is the web based application intended for restaurant's Businesses.It provide various feature such as searching,viewing and selection of food items from restaurant for customers.This Application also provides restaurant management and menu management for restaurant manager or owner.

## Software Requirements

Programming languages : Python

Operating System : Windows/Linux

Web Technologies : Django(2.0),Html,Css,Javascript

Database : Sqlite

demo -

#### Setup To Run

```
pip install -r requirements.txt
```

```
python manage.py runserver
```

# authors:

1)Gardas, sai vamshi krishna , UID :- U01873452
2)Sura, Avinash , UID :- U01883036
3)Gongalla, Rithika, UID :- U01881094
4)Komatineni, Kalpana, UID:- U01882978
